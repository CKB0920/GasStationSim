Every gas station has a rewards app nowadays
Good luck with the customers that don't know how to work cell phones

I want to add customer interactions that revolve around a rewards system. 
I want promos that would need to be displayed next to their relevant product being advertised on said promo. (For example, a sticker about a 2/$5 deal with soda would need to be displayed near where that exact brand /variety of soda is kept in the store)