I want weather to alternate subtly throughout the day.
Ex: Day starts mostly cloudy? Should the weather conditions slowly worsen or improve? 
	(Imagine having work performance impact weather. Shitty performance = Deteriorating weather.)
Severe weather events (such as Thunderstorms, Hail storms, Windy days, Tornado) should influence customer AI. This could affect customer count and [[NPC Behavior|customer behavior]].

# Weather events
## Basic Weather
### Light to moderate rain.
### Basic Fog
###
## Intense Weather ⚠
### Severe Thunderstorm ⛈
### Severe Rain 🌧

### Severe Wind 💨
### Tornado 🌪
### Dense Fog 🌫

### Hail storm 