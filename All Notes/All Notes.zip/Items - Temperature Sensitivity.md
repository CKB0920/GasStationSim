Items such as Ice Cream and other frozen or refrigerated goods should become ruined if kept outside of their cold zone for too long.
The game should take care as to notice if items are supposed to be either "Hot" "Chilled" or "Frozen"

### Hot items (Hot Case or Roller Grill)
- Hot Dogs
- Burgers
- Breakfast sandwiches
- Pizzas / Pizza Slices
### Chilled items (Deli-Case)
- Sandwiches 
- Cheese
- 
### Frozen items (Ice Cream Chest)
- Ice Cream Products
- Bags of Ice
- Frozen Foods
- 