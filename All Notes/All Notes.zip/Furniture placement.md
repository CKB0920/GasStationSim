"Hologram/Projection" style indicator
	Customizable color?