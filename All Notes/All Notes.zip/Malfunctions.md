# Machine Malfunctions
Nothing stays running (smoothly) forever. Machinery (especially those commonly used) are susceptible to Wear and Tear. I'm torn if I want deterioration to be implemented as something that deteriorates a machine (like a gas pump) as something that happens over time, or each time a customer interacts with it. 
## Machines susceptible to deterioration:
###
###
###
## Hiring Technicians for repairs.
While the player and other NPC cashiers might be able to clean these machines, it's going to take a professional to be able to fix them once deterioration catches up to them. You 