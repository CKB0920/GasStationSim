Items for the store can be ordered from the manager's computer.
When those items arrive, some of them (not many, only like 1-2 items) could either be expired, damaged, or missing, or an incorrect variety of that item (For example, you ordered orange flavored soda and received blueberry soda instead).
An even rarer possibility of receiving an extra item.

Player receives a list of their order with their delivery.
Player must visually inspect the received order to see if the order matches the list of the items the player ordered from the computer.