Look into things like datasets and variables?

# Personal Inventory
# Stock Inventory
# Item Details

## Product/Stock:








