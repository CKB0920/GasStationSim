Store should have ratings, maybe based around 5 stars.
NPCs can maybe also have a chance to leave reviews based on their experience in the store.
This mechanic probably should only be implemented later in the game. I don't want the player to get bombed with negative reviews at the start due to their initial lack of resources.

Reviews could revolve around:
- Store cleanliness
	Clean floors, clean counters, clean machines.
- Store product variety
	Having more variety of products.
	Having more variations of existing products. Like how there are different flavors of pop, etc.
- Customer service
	Can be worsened or improved based on employee's skills with customers.
- How fast service is completed
	(How fast players can check out customers and complete tasks)
- How stocked is the store?
	
- 
