
List of items that the player or NPC Cashiers could utilize to complete tasks.
# Uncategorized
- Utility knives / Box cutters
- Screwdrivers
- Hammers
- Tape
- Zip ties
- [[Utility Cart]]
# Cleaning related:
- Floor squeegees
- Mops & Buckets
- Scrubbers
- Dusters
- Brooms & Dustpans
- Trash Cans