The player should be able to defend themselves from a potentially hostile work environment. 
Not much thought up yet in terms of what to defend against though.
Robbery? Aggressive customer?
Should be rare, but if I decide to implement a difficulty slider, then maybe the odds increase more based on how high the difficulty is. Harder difficulty means a greater chance of a hostile encounter happening

Possible weapons are:
Knife, Bat, Taser, Glock, Rifle, Shotgun