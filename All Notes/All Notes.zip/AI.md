Potential to hire additional workers and potentially remote control?
Would I therefore still need a "Main Character/Player" in this instance?
	Well yes. Every store needs a Manager to run it and ensure it runs smoothly.
	A way to enforce this is to incorporate tasks /rooms that are exclusive to Managers. 
### General NPC Behavior
#### Reaction to [[Dynamic Weather|weather events]].
##### Lightning and Thunder 
Flashes of lightning or booms of thunder could either
- Stop NPCs for a few seconds
- Slow NPCs for a few seconds
NPCs looking at the windows at the time of the flash should react. 
Any other NPC that wasn't looking at the window should react to the boom of thunder, depending on severity.
  
### What to incorporate into Customer NPCs
- 

### What to incorporate into Employee NPCs
#### Skills
- Customer Service
- Work Efficiency
-  