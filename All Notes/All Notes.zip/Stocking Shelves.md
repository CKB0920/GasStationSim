Camera either remains bound to player 
OR
Camera moves into a fixed position relative to current shelf.
	Keybind / UI Button to move up/down shelves?
Two modes that can be chosen at first startup or anytime in the settings.
	
Shelf should know ItemID and Quantity(For stacked items)
###### Mode 1: Manual
Player stocks each shelf with each item individually.
Placed anywhere on the shelf.
###### Mode 2: Easy Place
First person only.
Player cursor highlights shelf to stock.
