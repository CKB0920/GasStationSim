Players should be able to adjust the gameplay to their styling and liking. Enough said.
Keep track of what can be customizable here.

Movement keys, 
jump
sprint
crouch
Inspect
Interact
Open Inventory