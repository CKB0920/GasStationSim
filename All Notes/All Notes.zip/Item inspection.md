Player presses a key and brings the item in their hand in front of them and allows the player to rotate the item, possibly even allowing me to implement something the player can interact with once visible by revealing it during inspection. 

Packets of paper could be interacted with to flip through pages.
Allowing players to write on papers for signing paperwork, or for checking off a list, or just drawing in general.
