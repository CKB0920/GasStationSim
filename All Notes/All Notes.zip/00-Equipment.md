Items that serve a significant purpose or function. Gameplay could revolve around these pieces of equipment here.
- Fountain Machine
- "Slurpee" Machine (Probably can't actually call it Slurpee)
