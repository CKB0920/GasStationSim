# Messes
"Messes" can be worsened the longer it is left unattended. Large or Overdue messes can prevent customers from accessing the area affected by the mess. Imagine a radius around the mess that prevent NPCs from being able to walk around it. However, certain customers, like [[Customers - Bad|Bad]] and [[Customers - Horrible|Horrible]] customers, will ignore this restriction and walk through this zone. This can maybe also cause them to create tracks (and therefore additional messes to clean) all across the store. This can be quite annoying, so maybe the chances of it happening should be minimal. 

---
# Machine Cleaning
I want each machine in store to have it's own "minigame" when cleaning is done.
Each minigame per step of the process for that machine.

Where the entire model of the machine is interactable. Exterior and Interior components.
Camera would detach from the first person character onto a fixed position relative to the position of the machine's "Base" model. The player should be able to move their cursor around and click and drag on the parts within the machine. 

Example actions: Opening panels, removing, storing machine parts back-stock and/or personal inventory, such as buckets, or other containers it could fit in for transport between machine and dish sink for cleaning and replacing parts.
##### Roller grill
- 
##### Oven
- Needs an interactable touch-screen in order to turn the oven off.
- Oven temperature should be tracked, damage player if cleaning is attempted before oven has cooled down enough.
- 
##### Hot case
- 
##### Coffee Machine / Coffee Pots
- 
##### Fountain Machine / Slush Machine

##### Gas Pump / Air Pump

---
# Cleaning the store
### Counters
	
### Floor
	
### Dishes
	
### 
	
### 
	
### 
	