There should be Missions or Objectives that can guide the player in their first play through.
Also long term goals for the player to shoot for.