Should the player and/or employees have hunger and thirst applied to them?
The hunger and thirst should deplete very slowly over time, barely noticeable. 
However, players and NPCs completing tasks should accelerate the depletion of that worker's hunger and thirst (dependent on the intensity of the task. The more physically intensive tasks should absorb more resources)

### Player archetypes?

### Player "Abilities"?
Focus:
	 Complete tasks faster or more efficiently for a limited time. Cooldown before useable again.
Observe:
	Highlights areas that need attention. Such as dirty areas (mops and counters), distressed customers
### Player should be able to:
Sit in chairs
Sprint
Jump
Crouch
