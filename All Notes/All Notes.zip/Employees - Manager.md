Has access to certain [[Restricted areas|restricted areas]]
Can lock and unlock doors.
