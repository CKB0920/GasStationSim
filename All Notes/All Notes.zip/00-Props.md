My "Props" are objects that don't serve a significant functionality. Simply noted here to include in my environment and to help me determine what to model myself if I must.
## Uncategorized for now


# General Furniture
- Counters
- Shelves
## Cleaning related:
- Wet-floor signs
- 