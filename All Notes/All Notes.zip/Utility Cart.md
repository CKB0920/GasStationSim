[Inspo](https://www.uline.com/Grp_37/Utility-Carts)
Can be used to carry cleaning supplies and/or extra stock.
Should use the [[Item dragging]] mechanic to function
- Sturdy structural foam. Rounded edges prevent wall damage.
- 2 5/8" deep trays are 19" apart.
- Non-marking 5" quiet rubber casters:  
  2 swivel, 2 rigid.
- [Utility Cart Accessories](https://www.uline.com/BL_3591/Uline-Utility-Cart-Accessories) available.
**Available Colors:**
- Black
- Grey
- Red
- Blue
- Green
- Yellow
# Standard
**Model #:** ?-XXXX
**Dimensions:** 
L - 45in (114.30 cm)
W - 25in (63.50 cm)
H - 33in (83.82 cm)
**Load Capacity:** 500lbs (226.80kg)
**Weight:** 43lbs (19.5045kg)
**Price:** $145
# **Narrow**
**Model No.:** ?-XXXX
**Dimensions:**
- L - 40in (101.6 cm)
- W - 18in (45.72 cm)
- H - 33in (83.82 cm)
**Load Capacity:** 500lbs (226.80kg)
**Weight:** 31lbs (14.0614kg)
**Price:** $140