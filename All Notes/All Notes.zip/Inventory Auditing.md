Encourages the player to crack down on item theft to ensure that they pass their audit.
(Recorded stock vs Actual stock)